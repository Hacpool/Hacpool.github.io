Hacash Solo Pool Miner v1.0.0

Bu paket sadece public miner dosyalari icin hazirlandi.
Kaynak kod ve pool server bu pakette yer almaz.

Icindekiler:
- poolworker
- install_deps_ubuntu.sh
- start_miner.sh
- start_miner_single.sh

Ubuntu bagimliliklari:
sudo bash ./install_deps_ubuntu.sh

NVIDIA kontrol:
nvidia-smi

Tum NVIDIA GPU'larla calistirma:
chmod +x ./poolworker ./start_miner.sh ./start_miner_single.sh
./start_miner.sh HACASH_WALLET rig01

Tek GPU ile calistirma:
./start_miner_single.sh HACASH_WALLET rig01 0

Varsayilan pool:
157.173.101.86:7101

Surum notu:
Bu public serinin baslangic surumu v1.0.0 olarak etiketlenmistir.
Sonraki guncellemeler v1.0.1, v1.0.2, v1.0.3 diye devam etmelidir.
